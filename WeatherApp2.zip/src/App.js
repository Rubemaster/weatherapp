import React, {Component} from 'react'
import * as ReactDOM from 'react-dom'

const PLACES=[
  {name: "PaloAlto", zip: "94303"},
  {name: "San Jose", zip: "94088"},
  {name: "Santa Cruz", zip: "95062"},
  {name: "Honolulu", zip: "96803"}
];
class WeatherResult extends Component{
  constructor(){
    super();
    this.state={
      weatherData: null,
    }
  }
  componentDidMount(){
    const zip= this.props.zip;
    const URL= "api.openweathermap.org/data/2.5/weather?zip="+zip+",us&appid=7fcf36d082463202fd7e914d4016395b";
    fetch(URL)
      .then(res => res.json())
      .then(json => {
        this.setState({weatherData: "json"});
      });
  }
  render(){
    const weatherData= this.state.weatherData;
    if(!weatherData)return(<h1>Loading.</h1>);
    return(<div>{weatherData}</div>);
  }
}
class WeatherDisplay extends Component{
  constructor() {
    super();
    this.state={
      activePlace: 0,
    }
  }
  render(){
    const activePlace=this.state.activePlace;
    return(
      <div>
        <h1>Hello, {PLACES[activePlace].zip}</h1>
        {PLACES.map((place,index)=>(
          <button
            key={index}
            onClick={()=>{
              console.log('Clicked index'+index);
              this.setState({activePlace: index});
            }}>
            {place.name}
          </button>))
        }  
        <WeatherResult zip={PLACES[activePlace].zip}/>
      </div>
    );
  }
}
ReactDOM.render(
  <div className="App">
    <header className="App-header">
    <WeatherDisplay/>
      <h3> React on Repl.it! </h3>
      <p>
        Edit <code>wut wut src/App.js</code> to get started!
      </p>
    </header>
  </div>,
  document.getElementById('root')
);
